c DCNF-Autarky [version 0.0.1]. 
c Copyright (c) 2018-2019 Swansea University. 
c 
c Input QBF/DQBF path: Akshay-Chakraborty-John-Shah-Rabe/arithmetic/decomposition32.qdimacs
c Output SAT Translation Path: /tmp/decomposition32.qdimacs-dcnfAutarky.dimacs
c Input Clause Count (tautology free): 772
c
c Performing E1-Autarky iteration.
c Remaining clauses count after E-Reduction: 771
c
c Performing A1-Autarky iteration.
c Running Lingeling ... 
c
c Remaining clauses count after A-Reduction: 0
c
c Input Parameter (command line, file): 
c input filename   Akshay-Chakraborty-John-Shah-Rabe/arithmetic/decomposition32.qdimacs
c output filename  /tmp/decomposition32.qdimacs-dcnfAutarky.dimacs
c autarky level    1
c conformity level 0
c encoding type    2
c no.of var        285
c no.of clauses    772
c no.of taut cls   0
c 
c Output Parameters: 
c remaining no.of clauses  0
c
c filename pn pc autarky ntaut rpa rpe rpcdiff result
c "Akshay-Chakraborty-John-Shah-Rabe/arithmetic/decomposition32.qdimacs" 285 772 "E1+A1" 0 0 0 772 "SAT" 
p cnf 285 0
