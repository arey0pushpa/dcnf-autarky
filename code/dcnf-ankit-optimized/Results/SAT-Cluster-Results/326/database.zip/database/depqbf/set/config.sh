#/bin/sh
run=ca16
cpus=2
time=2700
space=7000
binary=/home/ankit/test/depqbf
options=""
